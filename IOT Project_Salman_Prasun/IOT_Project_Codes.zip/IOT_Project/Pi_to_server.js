var net = require('net');
var fetch = require("node-fetch");

var HOST = '130.230.144.60';
// var HOST ='130.230.144.243';

var PORT = 3010;



// Create a server instance, and chain the listen function to it
// The function passed to net.createServer() becomes the event handler for the 'connection' event
// The sock object the callback function receives UNIQUE for each connection
net.createServer(function(sock) {

    // We have a connection - a socket object is assigned to the connection automatically
    console.log('CONNECTED: ' + sock.remoteAddress +':'+ sock.remotePort);

    var temp_data=[{building_id:"konetalo", room_id:"room1", occupancy:"empty"},
        {building_id:"konetalo", room_id:"room2", occupancy:"empty"}]


    // Add a 'data' event handler to this instance of socket
    sock.on('data', function(data) {

        console.log('DATA ' + sock.remoteAddress + ': ' + data);
        var curr_ip=(data.toString()).split(':')
        console.log(curr_ip[0],"and",curr_ip[1],"and",curr_ip[2]);
        var json_data_FL1={}

        json_data_FL1["building_id"]=curr_ip[0];
        json_data_FL1["room_id"]=curr_ip[1];
        json_data_FL1["occupancy"]=curr_ip[2];
        temp_data.push(json_data_FL1);
        // console.log(temp_data);
        var ready_array_for_json=make_order(temp_data);

        var final_json_to_send={}
        final_json_to_send["data"]=ready_array_for_json;
        console.log("final json to send",final_json_to_send)

        sendToExpress(final_json_to_send)
        // Write the data back to the socket, the client will receive it as data from the server
        //sock.write('You said "' + data + '"');
    });

    // Add a 'close' event handler to this instance of socket
    sock.on('close', function(data) {
        console.log('CLOSED: ' + sock.remoteAddress +' '+ sock.remotePort);
    });

}).listen(PORT, HOST);

console.log('Server listening on ' + HOST +':'+ PORT);




function sendToExpress(data) {
    var url = 'http://localhost:8080/sensor';
// var data = {username: 'example'};

    fetch(url, {
        method: 'POST', // or 'PUT'
        body: JSON.stringify(data), // data can be `string` or {object}!
        headers:{
            'Content-Type': 'application/json'
        }
    }).then(res => res.json())
        .catch(error => console.error('Error:', error))
        .then(response => console.log('Success:', response));
}
function make_order(data) {
    var uniqueNames = [];
    uniqueFinalData=[];

    for(i = 0; i< data.length; i++){

        if(uniqueNames.indexOf(data[i].building_id)===-1){
            uniqueNames.push(data[i].building_id);
            // unique_building["building_id"]=data[i].building_id;
        }
    }
    uniqueNames.forEach(function (element) {
        var temp_room_id_oc={}
        // var json_data_FL1={}

        for(var i=0;i<data.length;i++){
            //forloop_1

            if(data[i].building_id==element){
                temp_room_id_oc[data[i].room_id]=data[i].occupancy;
            }
        }
        Object.keys(temp_room_id_oc).forEach(function (key) {
            var json_data_FL1={}

            json_data_FL1["building_id"]=element;
            json_data_FL1["room_id"]=key;
            json_data_FL1["occupancy"]=temp_room_id_oc[key];
            uniqueFinalData.push(json_data_FL1);

        })
        // console.log("room loop",temp_room_id_oc)
    })
    return uniqueFinalData;
}

