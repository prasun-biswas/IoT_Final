

var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var fs = require('fs');

//var weather = require("openweather-node");
var mysql = require('mysql');
var index = require('./routes/index');
var users = require('./routes/users');

var app = express();
var hostname = 'localhost';
var port = 8080;
var server = require('http').Server(app);
var io = require('socket.io').listen(server);

// var connection = mysql.createConnection({
// //     host     : 'localhost',
// //     port     :  3306, //Port number to connect to for the DB.
// //     user     : 'root', //!!! NB !!! The user name you have assigned to work with the database.
// //     password : '123456', //!!! NB !!! The password you have assigned
// //     database : 'fis_assignment' //!!! NB !!! The database you would like to connect.
// // });
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', index);

roomData = [];

function dbData() {
    setInterval(function () {
        io.sockets.emit('data_port', roomData);
    },1000);
}

dbData();

app.post('/sensor',function(req,res) {
    roomData = req.body.data;
    // res.send("Ok");
});

// app.post('/student/add',function(req,res) {
//     // var jsonData=JSON.stringify(req.body)
//     // console.log(jsonData)
//     // for(var key in req.body){
//     //     //console.log(key,"has a value of:",req.body[key])
//     //     user[key]=req.body[key];
//     // }
//     console.log("received data", req.body)
//     //console.log(req.body)
//     //console.log(req.body.name,"is ",req.body.age," years old and studies in",req.body.institute)
// })

app.use(function(req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// error handler
app.use(function(err, req, res, next) {
    // set locals, only providing error in development
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};

    // render the error page
    res.status(err.status || 500);
    res.render('error');
});



server.listen(port, hostname, function(){
    console.log(`Server running at http://${hostname}:${port}/`);
});

module.exports = app;